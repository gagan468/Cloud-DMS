 <!-- plugins:css -->
 <link rel="stylesheet" href="vendors/feather/feather.css" />
 <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css" />
 <link rel="stylesheet" href="vendors/ti-icons/css/themify-icons.css" />
 <link rel="stylesheet" href="vendors/typicons/typicons.css" />
 <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css" />
 <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css" />
 <!-- endinject -->
 <!-- Plugin css for this page -->
 <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css" />
 <link rel="stylesheet" href="js/select.dataTables.min.css" />
 <!-- End plugin css for this page -->
 <!-- inject:css -->
 <link rel="stylesheet" href="css/vertical-layout-light/style.css" />
 <!-- endinject -->
 <link rel="shortcut icon" href="images/favicon.png" />

 <!-- Bootstrap icons CDN  -->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
 <!-- Rich Text editor  -->
 <link rel="stylesheet" href="richtexteditor/rte_theme_default.css" />
 <script type="text/javascript" src="richtexteditor/rte.js"></script>
 <script type="text/javascript" src='richtexteditor/plugins/all_plugins.js'></script>

 <!-- jquery -->
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

 <!-- PDF.js  -->
 <!-- <script src="https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js" integrity="sha256-W1eZ5vjGgGYyB6xbQu4U7tKkBvp69I9QwVTwwLFWaUY=" crossorigin="anonymous"></script>
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/web/pdf_viewer.min.css"> -->
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
